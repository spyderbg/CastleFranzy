// Utils.cpp
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Author(s): Ionut Matasaru
//
//	History: 10.07.2003, created
//			 10.07.2003, updated
//
////////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Utils.h"

//////////////////////////////////////////////////////////////////////

int CopyDynString(char** pszDest, const char* szSrc)
{
	if (*pszDest == szSrc)
		return (szSrc != NULL) ? lstrlen(szSrc) : -1;
	SAFE_DEL_ARRAY(*pszDest);
	if (!szSrc) return -1;
	int len = lstrlen(szSrc);
	*pszDest = new char[len + 1];
	TEST(*pszDest != NULL);
	lstrcpy(*pszDest, szSrc);
	return len;
}

//////////////////////////////////////////////////////////////////////
// returneaza un pointer temporar catre numele fisierului din calea data

char* GetFileName(char* szPath)
{
	if (!szPath) return NULL;

	int len = lstrlen(szPath);
	char *p = szPath + len;
	while (len)
	{
		if (*p == '\\') return p+1;
		p--; len--;
	}

	return szPath;
}

//////////////////////////////////////////////////////////////////////

void GetDisplayString(float f, char* str, int nDec)
{
	sprintf(str, "%f", f);
	if (!strchr(str, '.')) strcat(str, ".0");

	int nChars = lstrlen(str);
	while (nChars && str[nChars-1] == '0') str[--nChars] = '\0';
	if (str[nChars - 1] == '.') lstrcat(str, "0");
	if(nDec != -1)
	{
		char* p = str;
		while(*p != '.') p++;
		p[nDec+1] = 0;
	}
}

//////////////////////////////////////////////////////////////////////
// Nume: Clip()
// Desc: Calculeaza aria care se vede si pozitia acesteia
// Param:
//	 x, y = pozitia initiala (va fi modificata corespunzator)
//	 area = aria initiala (va fi modificata corespunzator)
//   pClipRect = aria la care se face clipping
// Return:
//	 true = s-a calculat cu succes si x, y, area au valori valide
//	 false = area este in afara dreptunghiului de clipping

bool Clip(long& x, long& y, RECT& area, RECT* pClipRect)
{
	if (pClipRect == NULL) return true;

	int nH = area.bottom - area.top;
	int nW = area.right - area.left;
	
	if (x < pClipRect->left)
	{
		nW -= pClipRect->left - x;
		area.left += pClipRect->left - x;
		x = pClipRect->left;
	}
	if (x + nW > pClipRect->right)
	{
		nW = pClipRect->right - x;
		area.right = area.left + nW;
	}
	if (y < pClipRect->top)
	{
		nH -= pClipRect->top - y;
		area.top += pClipRect->top - y;
		y = pClipRect->top;
	}
	if (y + nH > pClipRect->bottom)
	{
		nH = pClipRect->bottom - y;
		area.bottom = area.top + nH;
	}

	if (nH <= 0 || nW <= 0) return false;

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

long FileLength(FILE* f)
{
	long pos = ftell(f);
    fseek(f, 0L, SEEK_END);
	long len = ftell(f);
	fseek(f, pos, SEEK_SET);
	return len;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

BYTE* ReadFile(const char* szFile, int* pSize)
{
	FILE* f = fopen(szFile, "rb");
	if (!f) return NULL;

	int size = FileLength(f);
	if (pSize != NULL)
		*pSize = size;

	BYTE* pBuff = NULL;

	if (size > 0)
	{
		pBuff = new BYTE[size];
		fread(pBuff, size, 1, f);
	}

	fclose(f);
	return pBuff;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

BYTE* ReadScriptFile(const char* szFile, int* pSize)
{
	FILE* f = fopen(szFile, "rb");
	if (!f) return NULL;

	int size = FileLength(f);
	if (pSize != NULL)
		*pSize = size + 1;

	BYTE* pBuff = new BYTE[size + 1];
	if (size > 0)
		fread(pBuff, size, 1, f);
	pBuff[size] = 0;
	fclose(f);

	return pBuff;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

static void quicksort_n_n(int l, int r, int* a, int* b)
{
	int tmp;
	int i = l;
	int j = r;
	int x = a[(l+r)/2];
	do
	{
		while (a[i] < x) i++;
		while (x < a[j]) j--;
		if (i <= j) 
		{
			tmp = a[i]; a[i] = a[j]; a[j] = tmp;
			tmp = b[i]; b[i] = b[j]; b[j] = tmp;
			i++;
			j--;
		}
	} while (i <= j);
	if (l < j)  quicksort_n_n(l, j, a, b);
	if (i < r)  quicksort_n_n(i, r, a, b);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

void sort_n_n(int* a, int* b, int lo, int hi)
{
	ASSERT(0 <= lo && lo <= hi);
	quicksort_n_n(lo, hi, a, b);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

static char	msg[2048];

void out(FILE* f, const char* szFormat, ...)
{
	if (!szFormat) return;

	va_list va;
	va_start(va, szFormat);
	int len = vsprintf(msg, szFormat, va);
	va_end(va);

	if (len > 0)
	{
		if (f) fprintf(f, msg);
		printf(msg);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
