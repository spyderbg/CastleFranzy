// Parser_SEEK.cpp: implementation of the CParser class.
//////////////////////////////////////////////////////////////////////
//
//  Author(s): Ionut Matasaru
//
//  History: 23.08.2001, created
//			 19.10.2001, updated
//			 14.05.2002, SeekTokenDWORD() accept HEX numbers too
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Parser.h"

#ifdef USE_PARSER

//////////////////////////////////////////////////////////////////////

#define BEGIN_SEEK_TOKEN						\
	RestoreOverwrittenChar();					\
	SkipZeroOrMoreTokenDelimitators();			\
	int nSeekSavedState = SaveScriptState();	\

//////////////////////////////////////////////////////////////////////

#define END_SEEK_TOKEN							\
	TEST(m_pEndOfToken != NULL);				\
	SkipZeroOrMoreTokenDelimitators();			\
	m_cOverwrittenChar = *m_pEndOfToken;		\
	*m_pEndOfToken = '\0';						\
	ReleaseSavedScriptState(nSeekSavedState);	\

//////////////////////////////////////////////////////////////////////

#define SEEK_FAILED								\
{												\
	TRACE(CH_PARSER, "Seek FAILED !\n\tszToken: \"%.32s\"\n\tpCrtChar: \"%.32s\"", m_szToken, m_pCrtChar);	\
	RestoreScriptState(nSeekSavedState, true);	\
	return false;								\
}

//////////////////////////////////////////////////////////////////////

bool CParser::SeekNextToken()
{
	BEGIN_SEEK_TOKEN
	
	if (IsEOF()) SEEK_FAILED;

	m_szToken = m_pCrtChar;

	if (*m_pCrtChar == '"')
		return SeekTokenSTRING();
	else
	if (*m_pCrtChar >= '0' && *m_pCrtChar <= '9')
		return SeekTokenUnsignedNumber();
	else
	if (*m_pCrtChar == '-')
	{	
		if (*(m_pCrtChar+1) >= '0' && *(m_pCrtChar+1) <= '9')
			return SeekTokenSignedNumber();
		else
			return SeekTokenCHAR();
	}
	else
	if ((*m_pCrtChar >= 'a' && *m_pCrtChar <= 'z') || 
		(*m_pCrtChar >= 'A' && *m_pCrtChar <= 'Z') ||
		(*m_pCrtChar == '_'))
		return SeekTokenVNAME();
	else
		return SeekTokenCHAR();
/*
	END_SEEK_TOKEN
	m_dwTokenType = TOKEN_UNKNOWN;
	return true;
*/
}

//////////////////////////////////////////////////////////////////////
// bEscape = true -> escape sequences are expanded

bool CParser::SeekTokenSTRING(bool bEscape)
{
	BEGIN_SEEK_TOKEN

	if (*m_pCrtChar != '"') SEEK_FAILED;

	m_szToken = m_pCrtChar + 1;

	char* p = m_szTokenString;
	DWORD dw = 0;

	if (!bEscape)
	{
		while (Advance() && *m_pCrtChar != '"')
		{
			*p = *m_pCrtChar;
			p++;
		}
	}
	else
	{
		while (Advance() && *m_pCrtChar != '"')
		{
			char c = *m_pCrtChar;
			if (c == '\\')
			{
				if (!Advance()) break;
				c = *m_pCrtChar;
				switch (c)
				{
					case 'n': c = '\n'; break;
					case 'r': c = '\r'; break;
					case 't': c = '\t'; break;
					case '0':
						if (!Advance() || *m_pCrtChar != '0' ||
							!Advance() || *m_pCrtChar != '0') SEEK_FAILED;
						c = 0;
						break;

					case 'x':
						dw = 0;
						if (!Advance() || !DigitHEX(&dw, 4) ||
							!Advance() || !DigitHEX(&dw, 0)) SEEK_FAILED;
						c = (char)dw;
						break;

					case 'u':
						dw = 0;
						if (!Advance() || !DigitHEX(&dw, 12) ||
							!Advance() || !DigitHEX(&dw, 8) ||
							!Advance() || !DigitHEX(&dw, 4) ||
							!Advance() || !DigitHEX(&dw, 0)) SEEK_FAILED;
						c = (char)dw;
						break;
				}
			}
			*p = c;
			p++;
		}
	}

	*p = '\0';
	m_nTokenStringLen = (int)(p - m_szTokenString);

	if (*m_pCrtChar != '"') SEEK_FAILED;
	Advance();

	m_pEndOfToken = m_pCrtChar - 1;
	END_SEEK_TOKEN
	m_dwTokenType = TOKEN_STRING;

	return true;
}

//////////////////////////////////////////////////////////////////////

bool CParser::DigitHEX(DWORD* pDW, int nShift)
{
//	if (pDW == NULL) return false;
		 if (*m_pCrtChar >= '0' && *m_pCrtChar <= '9')	*pDW += ((*m_pCrtChar - '0'     ) << nShift);
	else if (*m_pCrtChar >= 'a' && *m_pCrtChar <= 'f')	*pDW += ((*m_pCrtChar - 'a' + 10) << nShift);
	else if (*m_pCrtChar >= 'A' && *m_pCrtChar <= 'F')	*pDW += ((*m_pCrtChar - 'A' + 10) << nShift);
	else return false;
	return true;
}

//////////////////////////////////////////////////////////////////////
// ok

bool CParser::SeekTokenVNAME()
{
	BEGIN_SEEK_TOKEN

	if ((*m_pCrtChar < 'a' || *m_pCrtChar > 'z') &&
		(*m_pCrtChar < 'A' || *m_pCrtChar > 'Z') &&
		(*m_pCrtChar != '_')) SEEK_FAILED;

	m_szToken = m_pCrtChar;

	while (Advance() &&
		   ((*m_pCrtChar >= 'a' && *m_pCrtChar <= 'z') ||
			(*m_pCrtChar >= 'A' && *m_pCrtChar <= 'Z') ||
			(*m_pCrtChar >= '0' && *m_pCrtChar <= '9') ||
			(*m_pCrtChar == '_')));
	
	m_pEndOfToken = m_pCrtChar;
	END_SEEK_TOKEN
	m_dwTokenType = TOKEN_VNAME;
//	TRACE(CH_PARSER, "VNAME: \"%s\" [%c]", m_szToken, m_cOverwrittenChar);
	return true;
}

//////////////////////////////////////////////////////////////////////
// ok

bool CParser::SeekTokenBOOL()
{
	BEGIN_SEEK_TOKEN

	if (!SeekTokenVNAME()) return false;

	if (lstrcmp(GetTokenVNAME(), "true") == 0)
		m_bTokenVal = true;
	else if (lstrcmp(GetTokenVNAME(), "false") == 0)
		m_bTokenVal = false;
	else
		SEEK_FAILED

	END_SEEK_TOKEN
	m_dwTokenType = TOKEN_VNAME | TOKEN_BOOL;
//	TRACE(CH_PARSER, "BOOL: \"%s\" [%c]", m_szToken, m_cOverwrittenChar);
	return true;
}

//////////////////////////////////////////////////////////////////////
// ok

bool CParser::SeekTokenCHAR()
{
	BEGIN_SEEK_TOKEN

//	TRACE(CH_PARSER, "[%c] [%c] [%c]", *(m_pCrtChar-1), *m_pCrtChar, *(m_pCrtChar+1));

	if (*m_pCrtChar == '\0') SEEK_FAILED;

	m_szToken = m_pCrtChar;

	Advance();

	m_pEndOfToken = m_pCrtChar;
	END_SEEK_TOKEN
	m_dwTokenType = TOKEN_CHAR;
//	TRACE(CH_PARSER, "CHAR: \"%s\" [%c]", m_szToken, m_cOverwrittenChar);
	return true;
}

//////////////////////////////////////////////////////////////////////
// ok

bool CParser::SeekTokenSIMBOL()
{
	BEGIN_SEEK_TOKEN

	if ((*m_pCrtChar == '\0') ||
		(*m_pCrtChar >= 'a' && *m_pCrtChar <= 'z') ||
		(*m_pCrtChar >= 'A' && *m_pCrtChar <= 'Z') ||
		(*m_pCrtChar >= '0' && *m_pCrtChar <= '9')) SEEK_FAILED;

	m_szToken = m_pCrtChar;
	
	Advance();

	m_pEndOfToken = m_pCrtChar;
	END_SEEK_TOKEN
	m_dwTokenType = TOKEN_CHAR | TOKEN_SIMBOL;
	return true;
}

//////////////////////////////////////////////////////////////////////
// todo: DWORD, INT, FLOAT

bool CParser::SeekTokenUnsignedNumber()
{
	BEGIN_SEEK_TOKEN
	
	END_SEEK_TOKEN
	m_dwTokenType = TOKEN_DWORD | TOKEN_INT | TOKEN_FLOAT;
	return true;
}

//////////////////////////////////////////////////////////////////////
// todo: INT, FLOAT

bool CParser::SeekTokenSignedNumber()
{
	BEGIN_SEEK_TOKEN
	
	END_SEEK_TOKEN
	m_dwTokenType = TOKEN_INT | TOKEN_FLOAT;
	return true;
}

//////////////////////////////////////////////////////////////////////
// todo: DWORD, INT, FLOAT

bool CParser::SeekTokenNumber()
{
	BEGIN_SEEK_TOKEN
	
	END_SEEK_TOKEN
	m_dwTokenType = TOKEN_DWORD | TOKEN_INT | TOKEN_FLOAT;
	return true;
}

//////////////////////////////////////////////////////////////////////
// ok

bool CParser::SeekTokenDWORD()
{
	BEGIN_SEEK_TOKEN

	BOOL bHex = FALSE;
	if ((*m_pCrtChar == '0') &&
		(*(m_pCrtChar+1) == 'x' || *(m_pCrtChar+1) == 'X'))
	{
		if (!Advance() || !Advance()) SEEK_FAILED;

		m_szToken = m_pCrtChar;

		while (((*m_pCrtChar >= '0' && *m_pCrtChar <= '9') || 
				(*m_pCrtChar >= 'a' && *m_pCrtChar <= 'f') ||
				(*m_pCrtChar >= 'A' && *m_pCrtChar <= 'F')) && Advance());

		if (m_pCrtChar - m_szToken == 0) SEEK_FAILED;
		if (m_pCrtChar - m_szToken > 8) { TRACE(CH_WARNING, "CParser - HEX number must have maximum 8 digits !"); SEEK_FAILED; }

		bHex = TRUE;
	}
	else
	{
		if (*m_pCrtChar < '0' || *m_pCrtChar > '9') SEEK_FAILED;

		m_szToken = m_pCrtChar;
	
		while (Advance() && *m_pCrtChar >= '0' && *m_pCrtChar <= '9');
	}

	m_pEndOfToken = m_pCrtChar;
	END_SEEK_TOKEN
	if (bHex)	sscanf(m_szToken, "%x", &m_dwTokenVal);
	else		m_dwTokenVal = (DWORD)atol(m_szToken);
	m_dwTokenType = TOKEN_DWORD;
	return true;
}

//////////////////////////////////////////////////////////////////////
// ok

bool CParser::SeekTokenHEX()
{
	BEGIN_SEEK_TOKEN

	if ((*m_pCrtChar == '0') &&
		(*(m_pCrtChar+1) == 'x' || *(m_pCrtChar+1) == 'X'))
	{
		if (!Advance() || !Advance()) SEEK_FAILED;
	}

	m_szToken = m_pCrtChar;

	while (((*m_pCrtChar >= '0' && *m_pCrtChar <= '9') || 
			(*m_pCrtChar >= 'a' && *m_pCrtChar <= 'f') ||
			(*m_pCrtChar >= 'A' && *m_pCrtChar <= 'F')) && Advance());

	if (m_pCrtChar - m_szToken == 0) SEEK_FAILED;
	if (m_pCrtChar - m_szToken > 8)  SEEK_FAILED;

	m_pEndOfToken = m_pCrtChar;
	END_SEEK_TOKEN
	sscanf(m_szToken, "%x", &m_dwTokenVal);
	m_dwTokenType = TOKEN_DWORD;
	return true;
}

//////////////////////////////////////////////////////////////////////
// ok

bool CParser::SeekTokenINT()
{
	BEGIN_SEEK_TOKEN

	if (*m_pCrtChar == '-' || *m_pCrtChar == '+')
	{ if (*(m_pCrtChar+1) < '0' || *(m_pCrtChar+1) > '9') SEEK_FAILED; }
	else
	{ if (*m_pCrtChar < '0' || *m_pCrtChar > '9') SEEK_FAILED; }

	m_szToken = m_pCrtChar;

	while (Advance() && *m_pCrtChar >= '0' && *m_pCrtChar <= '9');
	
	m_pEndOfToken = m_pCrtChar;
	END_SEEK_TOKEN
	m_nTokenVal = atoi(m_szToken);
	m_dwTokenType = TOKEN_INT;
	return true;
}

//////////////////////////////////////////////////////////////////////
// ok

bool CParser::SeekTokenFLOAT()
{
	BEGIN_SEEK_TOKEN

	if (*m_pCrtChar == '-')
	{ if (*(m_pCrtChar+1) < '0' || *(m_pCrtChar+1) > '9') SEEK_FAILED; }
	else
	{ if (*m_pCrtChar < '0' || *m_pCrtChar > '9') SEEK_FAILED; }

	m_szToken = m_pCrtChar;

	while (Advance() && *m_pCrtChar >= '0' && *m_pCrtChar <= '9');
	
	if (*m_pCrtChar != '.' || !Advance()) SEEK_FAILED;
	if (*m_pCrtChar < '0' || *m_pCrtChar > '9') SEEK_FAILED;
	
	while (Advance() && *m_pCrtChar >= '0' && *m_pCrtChar <= '9');
	
	if (*m_pCrtChar == 'f') Advance();
	
	m_pEndOfToken = m_pCrtChar;
	END_SEEK_TOKEN
	sscanf(m_szToken, "%f", &m_fTokenVal);
	m_dwTokenType = TOKEN_FLOAT;
	return true;
}

//////////////////////////////////////////////////////////////////////

DWORD CParser::GetTokenType()
{
	return m_dwTokenType;
}

//////////////////////////////////////////////////////////////////////

#endif USE_PARSER

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
