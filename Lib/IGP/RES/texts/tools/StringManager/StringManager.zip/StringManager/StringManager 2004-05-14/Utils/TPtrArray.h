// TPtrArray.h: interface and implementation of the TPtrArray template
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Author(s): Ionut Matasaru
//
//  History: 10.11.2003, created from TArray
//			 10.11.2003, updated
//
////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

////////////////////////////////////////////////////////////////////////////////////////////////////

#define T_INT int

#ifndef AFX_INLINE
#define AFX_INLINE __forceinline
#endif

#ifndef ASSERT
#ifdef _DEBUG
#define ASSERT TEST
#else
#define ASSERT
#endif
#endif

#ifndef MY_ASSERT_VALID
#ifdef _DEBUG
#define MY_ASSERT_VALID(x) { ASSERT((x) != NULL); (x)->AssertValid(); }
#else
#define MY_ASSERT_VALID(x)
#endif
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////
// TPtrArray<TYPE>
// note: TYPE must be a pointer type !

template<class TYPE>
class TPtrArray
{
// Methods...
public:
	TPtrArray();
	TPtrArray(T_INT nSize, T_INT nGrowBy = -1);
	~TPtrArray();

	// Get array dimensions...
	BOOL IsEmpty() const;			// return m_nSize == 0;
	T_INT GetSize() const;			// return m_nSize;
	T_INT GetUpperBound() const;	// return m_nSize-1;
	T_INT GetMaxSize() const;		// return m_nMaxSize;
	T_INT GetExtraSize() const;		// return m_nMaxSize - m_nSize;
	T_INT GetGrowBy() const;		// return m_nGrowBy;

	// Set array dimensions...
	void SetSize (T_INT nNewSize, T_INT nGrowBy = -1);
	void Resize  (T_INT nNewSize, T_INT nGrowBy = -1);		// SetSize(nNewSize, nGrowBy);
	void Increase(T_INT nAddSize);							// SetSize(m_nSize + nAddSize);
	void SetMaxSize(T_INT nNewMaxSize, T_INT nGrowBy = -1);
	void SetGrowBy(T_INT nGrowBy);							// m_nGrowBy = nGrowBy

	// Clean up...
	void FreeExtra();	// SetMaxSize(m_nSize);
	void Reset();		// SetSize(0);
	void Release();		// SetMaxSize(0);

	// Accessing elements...
	void SetAt(T_INT nIndex, TYPE newElement);	// m_pData[nIndex] = newElement;
	TYPE GetAt(T_INT nIndex) const;				// return m_pData[nIndex];
	TYPE& GetAt(T_INT nIndex);					// return (TYPE&)m_pData[nIndex];
	TYPE& ElementAt(INT_PTR nIndex);			// return (TYPE&)m_pData[nIndex];

	TYPE operator[](T_INT nIndex) const;		// return m_pData[nIndex];
	TYPE& operator[](T_INT nIndex);				// return (TYPE&)m_pData[nIndex];

	// Direct access to the element data (may return NULL)...
	const TYPE* GetData() const;				// return (const TYPE*)m_pData;
	TYPE* GetData();							// return (TYPE*)m_pData;

	void Switch(T_INT nIndexA, T_INT nIndexB);

	// Potentially growing the array...
	void SetAtGrow(T_INT nIndex, TYPE newElement);
	T_INT AddNewElem(TYPE newElement);	// Add(newElement);
	T_INT Add(TYPE newElement);
	T_INT Add(TYPE newElement, T_INT nCount);
	T_INT Append(const TPtrArray& src);
	T_INT Copy(const TPtrArray& src);

	// Operations that move elements around...
	void RemoveAt(T_INT nIndex, T_INT nCount = 1);
	void InsertAt(T_INT nIndex, TYPE newElement, T_INT nCount = 1);
	void InsertAt(T_INT nStartIndex, TPtrArray* pNewArray);

//	void Serialize(CArchive&);
#ifdef _DEBUG
//	void Dump(CDumpContext&) const;
	void AssertValid() const;
#endif

// Attributes...
protected:
	TYPE*		m_pData;		// the actual array of data
	T_INT		m_nSize;		// # of elements
	T_INT		m_nMaxSize;		// max allocated
	T_INT		m_nGrowBy;		// grow amount
};

////////////////////////////////////////////////////////////////////////////////////////////////////
// TPtrArray<TYPE> inline functions
////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
BOOL TPtrArray<TYPE>::IsEmpty() const				{ return m_nSize == 0; }

template<class TYPE> AFX_INLINE
T_INT TPtrArray<TYPE>::GetSize() const				{ return m_nSize; }

template<class TYPE> AFX_INLINE
T_INT TPtrArray<TYPE>::GetUpperBound() const		{ return m_nSize-1; }

template<class TYPE> AFX_INLINE
T_INT TPtrArray<TYPE>::GetMaxSize() const			{ return m_nMaxSize; }

template<class TYPE> AFX_INLINE
T_INT TPtrArray<TYPE>::GetExtraSize() const			{ return m_nMaxSize - m_nSize; }

template<class TYPE> AFX_INLINE
T_INT TPtrArray<TYPE>::GetGrowBy() const			{ return m_nGrowBy; }

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
void TPtrArray<TYPE>::Resize(T_INT nNewSize, T_INT nGrowBy = -1) { SetSize(nNewSize, nGrowBy); }

template<class TYPE> AFX_INLINE
void TPtrArray<TYPE>::Increase(T_INT nAddSize)		{ SetSize(m_nSize + nAddSize, -1); }

template<class TYPE> AFX_INLINE
void TPtrArray<TYPE>::FreeExtra()					{ SetMaxSize(m_nSize, -1); }

template<class TYPE> AFX_INLINE
void TPtrArray<TYPE>::Reset()						{ SetSize(0, -1); }

template<class TYPE> AFX_INLINE
void TPtrArray<TYPE>::Release()						{ SetMaxSize(0, -1); }

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
void TPtrArray<TYPE>::SetGrowBy(T_INT nGrowBy)
{
	if (nGrowBy != -1)
	{
		ASSERT(nGrowBy >= 0);
		m_nGrowBy = nGrowBy;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
void TPtrArray<TYPE>::SetAt(T_INT nIndex, TYPE newElement)
{
	ASSERT(nIndex >= 0 && nIndex < m_nSize);
	m_pData[nIndex] = newElement;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
TYPE TPtrArray<TYPE>::GetAt(T_INT nIndex) const
{
	ASSERT(nIndex >= 0 && nIndex < m_nSize);
	return m_pData[nIndex];
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
TYPE& TPtrArray<TYPE>::GetAt(T_INT nIndex)
{
	ASSERT(nIndex >= 0 && nIndex < m_nSize);
	return (TYPE&)m_pData[nIndex];
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
TYPE& TPtrArray<TYPE>::ElementAt(T_INT nIndex)
{
	ASSERT(nIndex >= 0 && nIndex < m_nSize);
	return (TYPE&)m_pData[nIndex];
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
TYPE TPtrArray<TYPE>::operator[](T_INT nIndex) const
{
	ASSERT(nIndex >= 0 && nIndex < m_nSize);
	return m_pData[nIndex];
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
TYPE& TPtrArray<TYPE>::operator[](T_INT nIndex)
{
	ASSERT(nIndex >= 0 && nIndex < m_nSize);
	return (TYPE&)m_pData[nIndex];
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
const TYPE* TPtrArray<TYPE>::GetData() const
{
	return (const TYPE*)m_pData;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
TYPE* TPtrArray<TYPE>::GetData()
{
	return (TYPE*)m_pData;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
void TPtrArray<TYPE>::Switch(T_INT nIndexA, T_INT nIndexB)
{
	MY_ASSERT_VALID(this);
	ASSERT(nIndexA >= 0 && nIndexA < m_nSize);
	ASSERT(nIndexB >= 0 && nIndexB < m_nSize);

//	TYPE t;
//	memcpy(&t,                 m_pData + nIndexA, sizeof(TYPE));
//	memcpy(m_pData + nIndexA,  m_pData + nIndexB, sizeof(TYPE));
//	memcpy(m_pData + nIndexB,  &t,                sizeof(TYPE));

	TYPE t = m_pData[nIndexA];
	m_pData[nIndexA] = m_pData[nIndexB];
	m_pData[nIndexB] = t;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE> AFX_INLINE
T_INT TPtrArray<TYPE>::AddNewElem(TYPE newElement)
{
	return Add(newElement);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// TPtrArray<TYPE> out-of-line functions
////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
TPtrArray<TYPE>::TPtrArray()
{
	m_pData = NULL;
	m_nSize = m_nMaxSize = m_nGrowBy = 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
TPtrArray<TYPE>::TPtrArray(T_INT nSize, T_INT nGrowBy)
{
	m_pData = NULL;
	m_nSize = m_nMaxSize = m_nGrowBy = 0;
	SetSize(nSize, nGrowBy);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
TPtrArray<TYPE>::~TPtrArray()
{
	MY_ASSERT_VALID(this);

	if (m_pData != NULL)
		delete[] (BYTE*)m_pData;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
void TPtrArray<TYPE>::SetSize(T_INT nNewSize, T_INT nGrowBy)
{
	MY_ASSERT_VALID(this);
	ASSERT(nNewSize >= 0);

	if (nGrowBy != -1)
	{
		ASSERT(nGrowBy >= 0);
		m_nGrowBy = nGrowBy;
	}

	if (nNewSize > m_nMaxSize)
	{
		nGrowBy = m_nGrowBy;
		if (nGrowBy == 0)
		{
			// heuristically determine growth when nGrowBy == 0
			// (this avoids heap fragmentation in many situations)
			nGrowBy = m_nSize / 8;
			nGrowBy = (nGrowBy < 4) ? 4 : ((nGrowBy > 1024) ? 1024 : nGrowBy);
		}
		T_INT nNewMax;
		if (nNewSize < m_nMaxSize + nGrowBy)
			nNewMax = m_nMaxSize + nGrowBy;		// granularity
		else
			nNewMax = nNewSize;					// no slush
		SetMaxSize(nNewMax);
	}

	ASSERT(m_nSize <= m_nMaxSize);
	if (nNewSize < m_nSize)
		memset((void*)(m_pData + nNewSize), 0, (size_t)(m_nSize-nNewSize) * sizeof(TYPE));

	m_nSize = nNewSize;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
void TPtrArray<TYPE>::SetMaxSize(T_INT nNewMaxSize, T_INT nGrowBy)
{
	MY_ASSERT_VALID(this);
	ASSERT(nNewMaxSize >= 0);

	if (nGrowBy != -1)
	{
		ASSERT(nGrowBy >= 0);
		m_nGrowBy = nGrowBy;
	}

	if (m_nMaxSize == nNewMaxSize)
		return;

	if (nNewMaxSize < m_nSize)
		m_nSize = nNewMaxSize; // shrink size

	if (nNewMaxSize == 0)
	{
		// shrink to nothing
		delete[] (BYTE*)m_pData;
		m_pData = NULL;
	}
	else
	{
		#ifdef SIZE_T_MAX
		ASSERT(nNewMaxSize <= SIZE_T_MAX/sizeof(TYPE)); // no overflow
		#endif

		TYPE* pNewData = (TYPE*) new BYTE[(size_t)nNewMaxSize * sizeof(TYPE)];

		if (m_nSize > 0)
			memcpy(pNewData, m_pData, (size_t)m_nSize * sizeof(TYPE));

		if (nNewMaxSize-m_nSize > 0)
			memset((void*)(pNewData + m_nSize), 0, (size_t)(nNewMaxSize-m_nSize) * sizeof(TYPE));

		if (m_pData != NULL)
			delete[] (BYTE*)m_pData;

		m_pData = pNewData;
	}

	m_nMaxSize = nNewMaxSize;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
T_INT TPtrArray<TYPE>::Append(const TPtrArray& src)
{
	MY_ASSERT_VALID(this);
	ASSERT(this != &src);	// cannot append to itself

	T_INT nOldSize = m_nSize;
	SetSize(m_nSize + src.m_nSize);
	CopyElements<TYPE>(m_pData + nOldSize, src.m_pData, src.m_nSize);
	return nOldSize;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
T_INT TPtrArray<TYPE>::Copy(const TPtrArray& src)
{
	MY_ASSERT_VALID(this);
	ASSERT(this != &src);	// cannot copy to itself

	T_INT nOldSize = m_nSize;
	SetSize(src.m_nSize);
	CopyElements<TYPE>(m_pData, src.m_pData, src.m_nSize);
	return nOldSize;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
void TPtrArray<TYPE>::SetAtGrow(T_INT nIndex, TYPE newElement)
{
	MY_ASSERT_VALID(this);
	ASSERT(nIndex >= 0);

	if (nIndex >= m_nSize)
		SetSize(nIndex+1, -1);
	m_pData[nIndex] = newElement;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
T_INT TPtrArray<TYPE>::Add(TYPE newElement)
{
	MY_ASSERT_VALID(this);

	T_INT nIndex = m_nSize;
	SetSize(m_nSize+1, -1);
	m_pData[nIndex] = newElement;
	return nIndex;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
T_INT TPtrArray<TYPE>::Add(TYPE newElement, T_INT nCount)
{
	MY_ASSERT_VALID(this);
	ASSERT(nCount > 0);

	T_INT nIndex = m_nSize;
	SetSize(nIndex+nCount, -1);
	for (T_INT i = nIndex; i < m_nSize; i++)
		m_pData[i] = newElement;
	return nIndex;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
void TPtrArray<TYPE>::RemoveAt(T_INT nIndex, T_INT nCount)
{
	MY_ASSERT_VALID(this);
	ASSERT(nIndex >= 0);
	ASSERT(nCount >= 0);
	ASSERT(nIndex + nCount <= m_nSize);

	T_INT nMoveCount = m_nSize - (nIndex + nCount);
	if (nMoveCount > 0)
		memmove(m_pData + nIndex, m_pData + nIndex + nCount, (size_t)nMoveCount * sizeof(TYPE));
	m_nSize -= nCount;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
void TPtrArray<TYPE>::InsertAt(T_INT nIndex, TYPE newElement, T_INT nCount /*=1*/)
{
	MY_ASSERT_VALID(this);
	ASSERT(nIndex >= 0);	// will expand to meet need
	ASSERT(nCount > 0);		// zero or negative size not allowed

	if (nIndex >= m_nSize)
	{
		// adding after the end of the array
		SetSize(nIndex + nCount, -1);	// grow so nIndex is valid
	}
	else
	{
		// inserting in the middle of the array
		T_INT nOldSize = m_nSize;
		SetSize(m_nSize + nCount, -1);	// grow it to new size
		// shift old data up to fill gap
		memmove(m_pData + nIndex + nCount, m_pData + nIndex, (nOldSize-nIndex) * sizeof(TYPE));
		// re-init slots we copied from
		memset((void*)(m_pData + nIndex), 0, (size_t)nCount * sizeof(TYPE));
	}

	// insert new value in the gap
	ASSERT(nIndex + nCount <= m_nSize);
	while (nCount--)
		m_pData[nIndex++] = newElement;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
void TPtrArray<TYPE>::InsertAt(T_INT nStartIndex, TPtrArray* pNewArray)
{
	MY_ASSERT_VALID(this);
	ASSERT(pNewArray != NULL);
	MY_ASSERT_VALID(pNewArray);
	ASSERT(nStartIndex >= 0);

	if (pNewArray->GetSize() > 0)
	{
		InsertAt(nStartIndex, pNewArray->GetAt(0), pNewArray->GetSize());
		for (T_INT i = 0; i < pNewArray->GetSize(); i++)
			SetAt(nStartIndex + i, pNewArray->GetAt(i));
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
/*
template<class TYPE>
void TPtrArray<TYPE>::Serialize(CArchive& ar)
{
	MY_ASSERT_VALID(this);

	CObject::Serialize(ar);
	if (ar.IsStoring())
	{
		ar.WriteCount(m_nSize);
	}
	else
	{
		DWORD_PTR nOldSize = ar.ReadCount();
		SetSize(nOldSize, -1);
	}
	SerializeElements<TYPE>(ar, m_pData, m_nSize);
}
*/
////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef _DEBUG
/*
template<class TYPE>
void TPtrArray<TYPE>::Dump(CDumpContext& dc) const
{
	CObject::Dump(dc);

	dc << "with " << m_nSize << " elements";
	if (dc.GetDepth() > 0)
	{
		dc << "\n";
		DumpElements<TYPE>(dc, m_pData, m_nSize);
	}

	dc << "\n";
}
*/
////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TYPE>
void TPtrArray<TYPE>::AssertValid() const
{
//	CObject::AssertValid();

	if (m_pData == NULL)
	{
		ASSERT(m_nSize == 0);
		ASSERT(m_nMaxSize == 0);
	}
	else
	{
		ASSERT(m_nSize >= 0);
		ASSERT(m_nMaxSize > 0);
		ASSERT(m_nSize <= m_nMaxSize);
	//	ASSERT(AfxIsValidAddress(m_pData, m_nMaxSize * sizeof(TYPE)));
	}
}

#endif //_DEBUG
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
