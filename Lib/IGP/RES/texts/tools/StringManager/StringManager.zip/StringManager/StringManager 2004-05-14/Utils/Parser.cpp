// Parser.cpp: implementation of the CParser class.
//////////////////////////////////////////////////////////////////////
//
//  Author(s): Ionut Matasaru
//
//  History: 22.08.2001, created
//			 19.10.2001, updated
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Parser.h"

#ifdef USE_PARSER

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CParser::CParser()
{
	m_pMainScript		= NULL;
	
	m_pScriptStack[0]	= NULL;
	m_pContinuePos[0]	= NULL;
	m_nDepth			= 0;

	m_dwState			= 0;
	m_bEOF				= false;
	m_nCrtPos			= 0;
	m_nCrtLine			= 0;
	m_nCrtCol			= 0;
	
	m_pCrtChar			= NULL;
	
	m_bFirstToken		= false;
	m_dwTokenType		= TOKEN_INVALID;
	m_szToken			= NULL;
	m_pEndOfToken		= NULL;
	m_cOverwrittenChar	= 0;

	m_szTokenString[0]	= 0;
	m_nTokenStringLen	= 0;

	ZeroMemory(m_pSavedState, MAX_SAVED_STATES * sizeof(TParserState*));
	m_nSavedStates		= 0;
}

//////////////////////////////////////////////////////////////////////

CParser::~CParser()
{
	Release();
}

//////////////////////////////////////////////////////////////////////
// Public
//////////////////////////////////////////////////////////////////////

void CParser::Release()
{
	TRACE(CH_PARSER, "Release()...");

	if (m_cOverwrittenChar != 0)
	{
		TEST(m_pEndOfToken != NULL);
		*m_pEndOfToken = m_cOverwrittenChar;
	}
	
	while (m_pMainScript)
	{
		TScript* p = m_pMainScript;
		m_pMainScript = m_pMainScript->pNext;
		SAFE_DEL(p);
	}

	m_pScriptStack[0]	= NULL;
	m_pContinuePos[0]	= NULL;
	m_nDepth			= 0;

	m_dwState			= 0;
	m_bEOF				= false;
	m_nCrtPos			= 0;
	m_nCrtLine			= 0;
	m_nCrtCol			= 0;
	
	m_pCrtChar			= NULL;
	
	m_bFirstToken		= false;
	m_dwTokenType		= TOKEN_INVALID;
	m_szToken			= NULL;
	m_pEndOfToken		= NULL;
	m_cOverwrittenChar	= 0;

	m_szTokenString[0]	= 0;
	m_nTokenStringLen	= 0;

	ReleaseAllSavedScriptStates();
	
	TRACE(CH_PARSER, "...Release()");
}

//////////////////////////////////////////////////////////////////////

HRESULT CParser::UseScriptFile(const char* szFileName)
{
	DECLARE_FN_NAME("CParser::UseScriptFile()");

	TRACE(CH_PARSER, "UseScriptFile(\"%s\")...", szFileName);
	TEST(szFileName != NULL);

	int size;
    LPBYTE buff = ReadScriptFile(szFileName, &size);
	if (buff == NULL)
	{
		TRACE_ERROR("ReadScriptFile() FAILED !");
		return ERR_FAIL;
	}

	HRESULT hr = UseScriptString((char*)buff, size-1);
	if (FAILED(hr))
	{
		SAFE_DEL_ARRAY(buff);
		TRACE_HRESULT(hr, "UseScriptString() FAILED !");
		return hr;
	}
	
	CopyDynString(&m_pMainScript->szFile, szFileName);
	m_pMainScript->bMustBeDelete = true;

	TRACE(CH_PARSER, "...UseScriptFile(\"%s\")", szFileName);
	return ERR_OK;
}

//////////////////////////////////////////////////////////////////////

HRESULT CParser::IncludeScriptFile(const char* szFileName)
{
	DECLARE_FN_NAME("CParser::IncludeScriptFile()");
	TRACE(CH_PARSER, "IncludeScriptFile(\"%s\")...", szFileName);
	TEST(szFileName != NULL);

	TScript* pScr = m_pMainScript;
	while (pScr != NULL)
	{
		if (pScr->szFile != NULL && lstrcmp(pScr->szFile, szFileName) == 0)
		{
			TRACE(CH_PARSER, "Optimization: Script file allready loaded !");

			m_pContinuePos[m_nDepth] = m_pCrtChar;
			m_nDepth++;
			m_pScriptStack[m_nDepth] = pScr;
			m_pCrtChar = pScr->szScript;

			TRACE(CH_PARSER, "...IncludeScriptFile(\"%s\")", szFileName);
			return ERR_OK;
		}
		pScr = pScr->pNext;
	}

	int size;
	LPBYTE buff = ReadScriptFile(szFileName, &size);
	if (buff == NULL)
	{
		TRACE_ERROR("ReadScriptFile() FAILED !");
		return ERR_FAIL;
	}

	HRESULT hr = IncludeScriptString((char*)buff, size-1);
	if (FAILED(hr))
	{
		SAFE_DEL_ARRAY(buff);
		TRACE_HRESULT(hr, "IncludeScriptString() FAILED !");
		return hr;
	}

	CopyDynString(&m_pScriptStack[m_nDepth]->szFile, szFileName);
	m_pScriptStack[m_nDepth]->bMustBeDelete = true;
	
	TRACE(CH_PARSER, "...IncludeScriptFile(\"%s\")", szFileName);
	return ERR_OK;
}

//////////////////////////////////////////////////////////////////////
	
HRESULT CParser::UseScriptString(char* szBuffer, int nLength)
{
	if (!szBuffer) return ERR_FAIL;

	Release();

	TScript* pScr = new TScript();
	TEST(pScr != NULL);
	
	pScr->szScript = szBuffer;
	if (nLength < 0)	pScr->nLength = lstrlen(szBuffer);
	else				pScr->nLength = nLength;
	
	m_pMainScript = pScr;
	m_nDepth = 0;
	m_pScriptStack[m_nDepth] = pScr;
	m_pCrtChar = pScr->szScript;

	return ERR_OK;
}

//////////////////////////////////////////////////////////////////////

HRESULT CParser::IncludeScriptString(char* szBuffer, int nLength)
{
	if (m_nDepth >= MAX_INCLUDE_DEPTH) return ERR_FAIL;
	if (m_nDepth < 0) return UseScriptString(szBuffer, nLength);

	TEST(m_pMainScript != NULL);
	TScript* pScr = m_pMainScript;
	while (pScr->pNext != NULL) pScr = pScr->pNext;

	pScr->pNext = new TScript();
	pScr = pScr->pNext;
	TEST(pScr != NULL);

	pScr->szScript = szBuffer;
	if (nLength < 0)	pScr->nLength = lstrlen(szBuffer);
	else				pScr->nLength = nLength;

	m_pContinuePos[m_nDepth] = m_pCrtChar;
	m_nDepth++;
	m_pScriptStack[m_nDepth] = pScr;
	m_pCrtChar = pScr->szScript;

	return ERR_OK;
}

//////////////////////////////////////////////////////////////////////

HRESULT CParser::EndCrtScript()
{
	if (m_nDepth > 0)
	{
		m_nDepth--;
		m_pCrtChar = m_pContinuePos[m_nDepth];
	}
	else
	{
		m_bEOF = true;
	}

	return ERR_OK;
}

//////////////////////////////////////////////////////////////////////
// Name: Scan()
// Desc: Read parameters specified by a template string
// Return: 1 (successfull) or 0 (error)
// Obs.: For strings and vnames you must specify a char** (memory will be allocated internally) !

#define SCAN_FAILED					\
{									\
	RestoreScriptState(save, true);	\
	va_end(marker);					\
	return 0;	 /* nReadItems */	\
}

int CParser::Scan(char* szTemplate, ...)
{
	TEST(szTemplate != NULL);

	va_list marker;
	va_start(marker, szTemplate);
	int nReadItems = 0;
	int save = SaveScriptState();

	char* pTempChar = szTemplate;
	while (*pTempChar != '\0')
	{
		if (*pTempChar == '%')
		{
			pTempChar++;
			switch (*pTempChar)
			{
			case '+':
				if (!SkipOneOrMoreTokenDelimitators()) SCAN_FAILED;
				break;
			case '*':
				SkipZeroOrMoreTokenDelimitators();
				break;
			case 'l':
				if (!m_bFirstToken) SCAN_FAILED;
				break;
			case 'v':
				if (!SeekTokenVNAME()) SCAN_FAILED;
			//	lstrcpy(va_arg(marker, char*), GetTokenVNAME());
				{
					char** psz = va_arg(marker, char**);
					*psz = new char[GetTokenLength()+1];
					TEST(*psz != NULL);
					lstrcpy(*psz, GetTokenVNAME());
				}
				nReadItems++;
				break;
			case 's':
				if (!SeekTokenSTRING()) SCAN_FAILED;
			//	lstrcpy(va_arg(marker, char*), GetTokenSTRING());
				{
					char** psz = va_arg(marker, char**);
					*psz = new char[GetStringLength()+1];
					TEST(*psz != NULL);
					lstrcpy(*psz, GetTokenSTRING());
				}
				nReadItems++;
				break;
			case 'c':
				if (!SeekTokenCHAR()) SCAN_FAILED;
				*va_arg(marker, char*) = GetTokenCHAR();
				nReadItems++;
				break;
			case 'u':
				if (!SeekTokenDWORD()) SCAN_FAILED;
				*va_arg(marker, DWORD*) = GetTokenDWORD();
				nReadItems++;
				break;
			case 'x':
				if (!SeekTokenHEX()) SCAN_FAILED;
				*va_arg(marker, DWORD*) = GetTokenDWORD();
				nReadItems++;
				break;
			case 'd':
			case 'i':
				if (!SeekTokenINT()) SCAN_FAILED;
				*va_arg(marker, int*) = GetTokenINT();
				nReadItems++;
				break;
			case 'f':
				if (!SeekTokenFLOAT()) SCAN_FAILED;
				*va_arg(marker, float*) = GetTokenFLOAT();
				nReadItems++;
				break;
			case '%':
				if (!SkipCHAR('%')) SCAN_FAILED;
				break;
			default:
				SCAN_FAILED;
			}
		}
		else
		{
			if (!SkipCHAR(*pTempChar)) SCAN_FAILED;
		}
		pTempChar++;
	}

	va_end(marker);
	
	ReleaseSavedScriptState(save);
	return 1; // nReadItems;
}

//////////////////////////////////////////////////////////////////////
// Name: ReadLoop()
// Desc: Try to unify multiple instances of the template
//       Write readed params in user buffer
//       Sets script pointer at the end of the last unified instance
// Returns:	number of instances unified

#define READ_LOOP_FAILED			\
{									\
	RestoreScriptState(save, true);	\
	return nReadTimes;				\
}

int CParser::ReadLoop(char* szTemplate, void* pBuffer, int nTimes)
{
	TEST(szTemplate != NULL);
	TEST(pBuffer != NULL);
	TEST(nTimes >= 0);

	int nReadTimes = 0;
	LPBYTE pBuf = (LPBYTE)pBuffer;

	while (true)
	{
		int save = SaveScriptState();

		char* pTempChar = szTemplate;
		while (*pTempChar != '\0')
		{
			if (*pTempChar == '%')
			{
				pTempChar++;
				switch (*pTempChar)
				{
				case '+':
					if (!SkipOneOrMoreTokenDelimitators()) READ_LOOP_FAILED;
					break;
				case '*':
					SkipZeroOrMoreTokenDelimitators();
					break;
				case 'l':
					if (!m_bFirstToken) READ_LOOP_FAILED;
					break;
				case 'v':
					if (!SeekTokenVNAME()) READ_LOOP_FAILED;
					lstrcpy((char*)pBuf, GetTokenVNAME());
					pBuf += GetTokenLength() + 1;
					break;
				case 's':
					if (!SeekTokenSTRING()) READ_LOOP_FAILED;
					lstrcpy((char*)pBuf, GetTokenSTRING());
					pBuf += GetStringLength() + 1;
					break;
				case 'c':
					if (!SeekTokenCHAR()) READ_LOOP_FAILED;
					*(char*)pBuf = GetTokenCHAR();
					pBuf++;
					break;
				case 'u':
					if (!SeekTokenDWORD()) READ_LOOP_FAILED;
					*(DWORD*)pBuf = GetTokenDWORD();
					pBuf += 4;
					break;
				case 'x':
					if (!SeekTokenHEX()) READ_LOOP_FAILED;
					*(DWORD*)pBuf = GetTokenDWORD();
					pBuf += 4;
					break;
				case 'd':
				case 'i':
					if (!SeekTokenINT()) READ_LOOP_FAILED;
					*(int*)pBuf = GetTokenINT();
					pBuf += 4;
					break;
				case 'f':
					if (!SeekTokenFLOAT()) READ_LOOP_FAILED;
					*(float*)pBuf = GetTokenFLOAT();
					pBuf += 4;
					break;
				case '%':
					if (!SkipCHAR('%')) READ_LOOP_FAILED;
					break;
				default:
					READ_LOOP_FAILED;
				}
			}
			else
			{
				if (!SkipCHAR(*pTempChar)) READ_LOOP_FAILED;
			}
			pTempChar++;
		}
		
		nReadTimes++;
		ReleaseSavedScriptState(save);

		if (nTimes > 0 && nReadTimes == nTimes) return nReadTimes;
	}
}

//////////////////////////////////////////////////////////////////////
	
void CParser::UpdatePosIndices()
{
	/*
	if (!SRC) { ln=-1; col=-1; return; }
	ln = 1;
	int i=0;
	while(i<sp)
	{
		if(SRC[i]==13){ ln++; col=1; }
		else
		if(SRC[i]=='\t') col+=TAB_SIZE;
		else
		if(SRC[i]>=32 && SRC[i]<=127) col++;
		i++;
	}
	*/
}

//////////////////////////////////////////////////////////////////////

int CParser::SaveScriptState()
{
	DECLARE_FN_NAME("CParser::SaveScriptState()");
	TEST(m_nSavedStates < MAX_SAVED_STATES);

	for (int i = 0; i < MAX_SAVED_STATES; i++)
	{
		if (m_pSavedState[i] == NULL)
		{
			m_pSavedState[i] = new TParserState();
			TEST(m_pSavedState[i] != NULL);
			
			m_pSavedState[i]->nDepth   = m_nDepth;
			m_pSavedState[i]->pCrtChar = m_pCrtChar;
			m_pSavedState[i]->nCrtLine = m_nCrtLine;
			m_nSavedStates++;

			return i;
		}
	}

	TRACE_ERROR("empty save slot not found !");
	return -1;
}

//////////////////////////////////////////////////////////////////////

void CParser::RestoreScriptState(int state, bool release)
{
	TEST(state >= 0 && state < MAX_SAVED_STATES);
	TEST(m_pSavedState[state] != NULL);			// not a valid save ?

	m_nDepth	= m_pSavedState[state]->nDepth;
	m_pCrtChar	= m_pSavedState[state]->pCrtChar;
	m_nCrtLine  = m_pSavedState[state]->nCrtLine;
	m_bEOF		= (*m_pCrtChar == 0);

	if (release) ReleaseSavedScriptState(state);
}

//////////////////////////////////////////////////////////////////////

void CParser::ReleaseSavedScriptState(int state)
{
	TEST(state >= 0 && state < MAX_SAVED_STATES);
	if (m_pSavedState[state] != NULL)
	{
		SAFE_DEL(m_pSavedState[state]);
		m_nSavedStates--;
	}
	else
	{
        TRACE(CH_WARNING, "CParser::ReleaseSavedScriptState(%d) FAILED !", state);
	}
}

//////////////////////////////////////////////////////////////////////

void CParser::ReleaseAllSavedScriptStates()
{
	for (int i = 0; i < MAX_SAVED_STATES; i++)
		SAFE_DEL(m_pSavedState[i]);
	m_nSavedStates = 0;
}

//////////////////////////////////////////////////////////////////////

HRESULT CParser::Error(HRESULT hr)
{
/*
	int ln,col;
	GetPos(ln, col);
	if(ln!=-1)	TRACE(CH_SCRIPT,"Error \"%s\" ln=%i,col=%i,adr=0x%x (exected: \"%s\")", szFile, ln, col, sp, szTemp);
	else		TRACE(CH_SCRIPT,"Error no script loaded");
*/
	TRACE(CH_ERROR, "Parse error (0x%08X) !", hr);
	return hr;
}

//////////////////////////////////////////////////////////////////////

HRESULT CParser::Warning(HRESULT hr)
{
	TRACE(CH_WARNING, "Parse warning (0x%08X) !", hr);
	return hr;
}

//////////////////////////////////////////////////////////////////////

#endif USE_PARSER

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
