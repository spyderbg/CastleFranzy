// Parser.inl: inline methods for the CParser class.
//////////////////////////////////////////////////////////////////////
//
//  Author(s): Ionut Matasaru
//
//  History: 23.08.2001, created
//			 09.10.2001, nBugs--
//			 19.10.2001, updated
//
//////////////////////////////////////////////////////////////////////

#pragma once

#ifdef USE_PARSER

//////////////////////////////////////////////////////////////////////

inline void CParser::RestoreOverwrittenChar()
{
	if (m_cOverwrittenChar != 0)
	{
		TEST(m_pEndOfToken != NULL);
		*m_pEndOfToken = m_cOverwrittenChar;
		m_pEndOfToken = NULL;
		m_cOverwrittenChar = 0;
	}
}

//////////////////////////////////////////////////////////////////////

inline bool CParser::IsEOFDelimitator(char c)
{
	return (c == 0 || IsEOF());
}

//////////////////////////////////////////////////////////////////////

inline bool CParser::IsLineDelimitator(char c)
{
	return (c == 10 || c == 13 || IsEOFDelimitator(c));
}

//////////////////////////////////////////////////////////////////////

inline bool CParser::IsTokenDelimitator(char c)
{
	return (c == ' ' || c == '\t' || IsLineDelimitator(c));
}

//////////////////////////////////////////////////////////////////////

inline bool CParser::Advance()
{
	if (m_bEOF) return false;

	if (*m_pCrtChar == 10)
	{
		m_nCrtLine++;
	}

	m_pCrtChar++;
	if (*m_pCrtChar == 0)
	{
		EndCrtScript();
	}

	if (m_bFirstToken && *m_pCrtChar == '#') ParseDirective();
	return true;
}

//////////////////////////////////////////////////////////////////////

inline void CParser::SkipToEndOfLine()
{
	while (!IsLineDelimitator(*m_pCrtChar))
	{
		if (!Advance()) return;
	}
	while (IsLineDelimitator(*m_pCrtChar))
	{
		if (!Advance()) return;
	}
}
//////////////////////////////////////////////////////////////////////

inline bool CParser::SkipComments()
{
	if (*m_pCrtChar == '/')
	{
		if (*(m_pCrtChar+1) =='/')
		{
			SkipToEndOfLine();
			return true;
		}
		else
		if (*(m_pCrtChar+1) == '*')
		{
			do { if (!Advance()) return false; }
			while (*m_pCrtChar != '*' || *(m_pCrtChar+1) != '/');
			if (!Advance()) return false;
			if (!Advance()) return false;
			return true;
		}
	}
	return false;
}

//////////////////////////////////////////////////////////////////////

inline void CParser::SkipZeroOrMoreTokenDelimitators()
{
	do {
		while (IsTokenDelimitator(*m_pCrtChar))
		{
			if (!Advance()) return;
		}
	}
	while (SkipComments());
}

//////////////////////////////////////////////////////////////////////

inline bool CParser::SkipOneOrMoreTokenDelimitators()
{
	SkipComments();
	if (IsTokenDelimitator(*m_pCrtChar))
	{
		Advance();
		SkipZeroOrMoreTokenDelimitators();
		return true;
	}
	else
	{
	//	Error(PARSE_ERR_NO_TOKEN_DELIMITATOR);
		return false;
	}
}

//////////////////////////////////////////////////////////////////////

inline void CParser::ParseDirective()
{
	TEST(m_bFirstToken == true);
	TEST(*m_pCrtChar == '#');

	SkipZeroOrMoreTokenDelimitators();
		
	SeekNextToken();
		
	if (IsToken("include"))
	{
		if (SeekTokenSTRING())
		{
			IncludeScriptFile(GetTokenSTRING());
		}
		else
		{
		//	Error(PARSE_ERR_DIRECTIVE_INCLUDE);
		}
	}
	else
	if (IsToken("message"))
	{
		if (SeekTokenSTRING())
		{
			TRACE(CH_PARSER, GetTokenSTRING());
		}
		else
		{
		//	Error(PARSE_ERR_DIRECTIVE_MESSAGE);
		}
	}
	else
	if (IsToken("eof"))
	{
		EndCrtScript();
	}
	else
	{
		SkipToEndOfLine();
	//	Warning(PARSE_WARN_UNKNOWN_DIRECTIVE);
	}
}

//////////////////////////////////////////////////////////////////////

inline bool CParser::SkipToken(char* tok)
{
	int nSeekSavedState = SaveScriptState();
	if (SeekNextToken() && IsToken(tok))
	{
		ReleaseSavedScriptState(nSeekSavedState);
		return true;
	}
	else
	{
		RestoreScriptState(nSeekSavedState, true);
		return false;
	}
}

//////////////////////////////////////////////////////////////////////

inline bool CParser::SkipVNAME(char* sz)
{
	int nSeekSavedState = SaveScriptState();
	if (SeekTokenVNAME() && (lstrcmp(sz, GetTokenVNAME()) == 0))
	{
		ReleaseSavedScriptState(nSeekSavedState);
		return true;
	}
	else
	{
		RestoreScriptState(nSeekSavedState, true);
		return false;
	}
}

//////////////////////////////////////////////////////////////////////

inline bool CParser::SkipCHAR(char c)
{
	int nSeekSavedState = SaveScriptState();
	if (SeekTokenCHAR() && c == GetTokenCHAR())
	{
		ReleaseSavedScriptState(nSeekSavedState);
		return true;
	}
	else
	{
		RestoreScriptState(nSeekSavedState, true);
		return false;
	}
}

//////////////////////////////////////////////////////////////////////

inline bool CParser::SkipSTRING(char* sz)
{
	int nSeekSavedState = SaveScriptState();
	if (SeekTokenSTRING() && (lstrcmp(sz, GetTokenSTRING()) == 0))
	{
		ReleaseSavedScriptState(nSeekSavedState);
		return true;
	}
	else
	{
		RestoreScriptState(nSeekSavedState, true);
		return false;
	}
}

//////////////////////////////////////////////////////////////////////

#endif USE_PARSER

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
