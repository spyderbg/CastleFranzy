// Parser.h: interface for the CParser class.
//////////////////////////////////////////////////////////////////////
//
//  Author(s): Ionut Matasaru
//
//  History: 22.08.2001, created
//			 23.08.2001, main work
//			 29.08.2001, updated
//
//////////////////////////////////////////////////////////////////////

#pragma once

#ifdef USE_PARSER

//////////////////////////////////////////////////////////////////////
//
//	Directives:
//	#include "file"				// include file
//	#message "bla bla bla"		// display a debug message
//	#eof						// force end of file
//
//	"%l %* # %* include %+ %s %+"
//	"%l %* # %* message %+ %s %+"
//	"%l %* # %* eof %+"
//
//	v_name = [_a-zA-Z][_a-zA-Z0-9]*
//	string = "..."
//	number = int | DWORD | hex | float
//	symbol = '~' | '!' | '@' | '#' | ...
//	token  = v_name | string | number | symbol
//	char   = [\x32 - \x128]
//
//	Tests...
//	ID		DESC
//	%l		start of line
//	%*		zero or more tokens delimitators
//	%+		one or more tokens delimitators
//	Variables....
//	ID		TYPE			SIZE		SAMPLES
//	%v		v_name			MAX_NAME	Var01 VAR_NAME
//	%c		char			1			0 a _ % .
//	%u		DWORD			4			1024
//	%i %d	int				4			100	-1000
//	%x		DWORD hex		4			0A A ff ff12a
//	%f		float			4			10.52f -100.0f
//	%s		string			MAX_TEXT	"test" "happy 1st day"
//
//  End of file delimitators : '\0', #eof directive
//  Lines delimitators		 : '\x10', '\x13', end of file delimitators
//  Tokens delimitators		 : ' ', '\t', lines delimitators
//
//////////////////////////////////////////////////////////////////////

#define MAX_INCLUDE_DEPTH		32

#define MAX_TOKEN_VNAME			MAX_FORMATTED_TEXT
#define MAX_TOKEN_STRING		MAX_FORMATTED_TEXT
#define MAX_TOKEN_DWORD			16
#define MAX_TOKEN_HEX			16
#define MAX_TOKEN_INT			16
#define MAX_TOKEN_FLOAT			32
#define MAX_PARAM_BUFFER		MAX_FORMATTED_TEXT

#define MAX_SAVED_STATES		128

//////////////////////////////////////////////////////////////////////
// Token types...

#define TOKEN_INVALID			0
#define TOKEN_UNKNOWN			1

#define TOKEN_STRING			(DWORD)(1 << 1)
#define TOKEN_VNAME				(DWORD)(1 << 2)
#define TOKEN_CHAR				(DWORD)(1 << 3)
#define TOKEN_DWORD				(DWORD)(1 << 4)
#define TOKEN_INT				(DWORD)(1 << 5)
#define TOKEN_FLOAT				(DWORD)(1 << 6)

#define TOKEN_BOOL				(DWORD)(1 << 7)
#define TOKEN_SIMBOL			(DWORD)(1 << 8)

#define TEST_TOKEN_TYPE(t)		{ TEST((t & GetTokenType()) != 0); }

//////////////////////////////////////////////////////////////////////

class CParser
{
// Structures...
protected:
	struct TScript
	{
		TScript() :
			szFile(NULL),
			szScript(NULL),
			nLength(0),
			bMustBeDelete(false),
			pNext(NULL) {}

		~TScript()
		{
			SAFE_DEL_ARRAY(szFile);
			if (bMustBeDelete) SAFE_DEL_ARRAY(szScript);
		}

		char*		szFile;
		char*		szScript;
		int			nLength;
		bool		bMustBeDelete;
		
		TScript*	pNext;
	};

	struct TParserState
	{
		int			nDepth;
		char*		pCrtChar;
		int 		nCrtLine;
	};


// Methods...
public:
	CParser();
	virtual ~CParser();

	void Release();

	//------------------------
	// Set / unset scripts...

	HRESULT UseScriptFile(const char* szFileName);
	HRESULT IncludeScriptFile(const char* szFileName);
	HRESULT UseScriptString(char* szBuffer, int nLength = -1);
	HRESULT IncludeScriptString(char* szBuffer, int nLength = -1);
	
	HRESULT EndCrtScript();
	
	//------------------------
	// Template unification...

	int Scan(char* szTemplate, ...);
	int ReadLoop(char* szTemplate, void* pBuffer, int nTimes = 1);

//	void* GetParamPtr(int offset = 0)		{ return m_pParamBuf != NULL ? m_pParamBuf + offset : NULL; }
//	int GetParamBufferSize()				{ return m_nParamBufSize; }
//	int GetParamInt(int offset = 0)			{ TEST(m_pParamBuf != NULL); return *(int*)(m_pParamBuf + offset); }
//	float GetParamFloat(int offset = 0)		{ TEST(m_pParamBuf != NULL); return *(float*)(m_pParamBuf + offset); }
//	bool GetParamBool(int offset = 0)		{ TEST(m_pParamBuf != NULL); return *(bool*)(m_pParamBuf + offset); }
//	DWORD GetParamDWord(int offset = 0)		{ TEST(m_pParamBuf != NULL); return *(DWORD*)(m_pParamBuf + offset); }
//	char* GetParamString(int offset = 0)	{ TEST(m_pParamBuf != NULL); return (char*)(m_pParamBuf + offset); }
	
	//------------------------
	// Tokens...

	// Seek token methods...
	// (advance to next token if true is returned !)
	bool SeekNextToken();						// all
	bool SeekTokenSTRING(bool bEscape = false);	// STRING
	bool DigitHEX(DWORD* pDW, int nShift);
	bool SeekTokenVNAME();						// VNAME
	bool SeekTokenBOOL();						// VNAME, BOOL
	bool SeekTokenCHAR();						// CHAR
	bool SeekTokenSIMBOL();						// CHAR, SIMBOL
	bool SeekTokenUnsignedNumber();				// DWORD, INT, FLOAT
	bool SeekTokenSignedNumber();				// INT, FLOAT
	bool SeekTokenNumber();						// DWORD, INT, FLOAT
	bool SeekTokenDWORD();						// DWORD
	bool SeekTokenHEX();						// DWORD
	bool SeekTokenINT();						// INT
	bool SeekTokenFLOAT();						// FLOAT
	
	// Get token's value...
	// (no validation is made in release compilation !)
	char* GetToken()			{ return m_szToken; }
	char* GetTokenVNAME()		{ TEST_TOKEN_TYPE(TOKEN_VNAME); return m_szToken; }
	char  GetTokenCHAR()		{ TEST_TOKEN_TYPE(TOKEN_CHAR); return m_szToken[0]; }
	char  GetTokenSIMBOL()		{ TEST_TOKEN_TYPE(TOKEN_SIMBOL); return m_szToken[0]; }
	char* GetTokenSTRING()		{ TEST_TOKEN_TYPE(TOKEN_STRING); return m_szTokenString; }
	DWORD GetTokenDWORD()		{ TEST_TOKEN_TYPE(TOKEN_DWORD); return m_dwTokenVal; }
	DWORD GetTokenHEX()			{ return GetTokenDWORD(); }
	int   GetTokenINT()			{ TEST_TOKEN_TYPE(TOKEN_INT); return m_nTokenVal; }
	bool  GetTokenBOOL()		{ TEST_TOKEN_TYPE(TOKEN_BOOL); return m_bTokenVal; }
	float GetTokenFLOAT()		{ TEST_TOKEN_TYPE(TOKEN_FLOAT); return m_fTokenVal; }

	// Token description...
	DWORD GetTokenType();
	int GetTokenLength()		{ return (int)(m_pEndOfToken - m_szToken); }
	int GetStringLength()		{ return m_nTokenStringLen; }

	bool IsToken(char* tok)		{ return 0 == lstrcmp(tok, GetToken()); }
	bool NotToken(char* tok)	{ return 0 != lstrcmp(tok, GetToken()); }

	bool IsEOF()				{ return m_bEOF; }
	bool NotEOF()				{ return !m_bEOF; }

	// Skip tokens...
	bool SkipToken(char* tok);
	bool SkipVNAME(char* sz);
	bool SkipCHAR(char c);
	bool SkipSTRING(char* sz);

	// Script statistics...
	void UpdatePosIndices();
	int GetCrtPos()				{ return m_nCrtPos; }
	int GetCrtLine()			{ return m_nCrtLine; }
	int GetCrtCol()				{ return m_nCrtCol; }
	char GetCrtChar()			{ return *m_pCrtChar; }
	char* GetCrtCharPtr()		{ return m_pCrtChar; }

	// Script states...
	int  SaveScriptState();
	void RestoreScriptState(int state, bool release);
	void ReleaseSavedScriptState(int state);
	void ReleaseAllSavedScriptStates();

protected:
	TScript* GetCrtScript()		{ return m_pScriptStack[m_nDepth]; }

	HRESULT Error(HRESULT hr);
	HRESULT Warning(HRESULT hr);

public:
	// Inlines...
	void RestoreOverwrittenChar();
	bool IsEOFDelimitator(char c);
	bool IsLineDelimitator(char c);
	bool IsTokenDelimitator(char c);
	bool Advance();
	void SkipToEndOfLine();
	bool SkipComments();
	void SkipZeroOrMoreTokenDelimitators();
	bool SkipOneOrMoreTokenDelimitators();
	void ParseDirective();

// Attributes...
protected:
	// List of loaded scripts buffers...
	TScript*		m_pMainScript;
	
	// #include file directive implementation using a call stack...
	TScript*		m_pScriptStack[MAX_INCLUDE_DEPTH];
	char*			m_pContinuePos[MAX_INCLUDE_DEPTH];
	int				m_nDepth;
	// m_pCallStack[0]			= m_pMainScript
	// m_pCallStack[m_nDepth]	= crt script

	// Parser stats...
	DWORD			m_dwState;
	bool			m_bEOF;
	int				m_nCrtPos;
	int				m_nCrtLine;
	int				m_nCrtCol;
	
	char*			m_pCrtChar;
	
	bool			m_bFirstToken;
	
	DWORD			m_dwTokenType;
	char*			m_szToken;
	char*			m_pEndOfToken;
	char			m_cOverwrittenChar;
	
	// Tokens value...
	bool			m_bTokenVal;
	DWORD			m_dwTokenVal;
	int				m_nTokenVal;
	float			m_fTokenVal;
	char			m_szTokenString[MAX_TOKEN_STRING];
	int				m_nTokenStringLen;

//	BYTE			m_pParamBuf[MAX_PARAM_BUFFER];
//	int				m_nParamBufSize;
//	LPBYTE			m_pLastParam;

	// Saved states...
	TParserState*	m_pSavedState[MAX_SAVED_STATES];
	int				m_nSavedStates;
};

//////////////////////////////////////////////////////////////////////

#include "Parser.inl"

#endif USE_PARSER

//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
