// StringManager.cpp : Defines the entry point for the console application.
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  Author(s): Viorel Munteanu, Ionut Matasaru
//
//	History: 10.01.2004, created
//			 27.01.2004, Ionut, updated
//			 11.03.2004, Ionut, source file can be other than ".txt"
//
////////////////////////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Utils/Parser.h"
//#include <winsock2.h> // for htons()

//using namespace std;

////////////////////////////////////////////////////////////////////////////////////////////////////

static FILE* bin	= NULL;
static FILE* idx	= NULL;
static FILE* h		= NULL;
static FILE* java	= NULL;

////////////////////////////////////////////////////////////////////////////////////////////////////

static void file_cleanup()
{
	if (bin)	{ fclose(bin);	bin = NULL; }
	if (idx)	{ fclose(idx);	idx = NULL; }
	if (h)		{ fclose(h);	h = NULL; }
	if (java)	{ fclose(java);	java = NULL; }
}

////////////////////////////////////////////////////////////////////////////////////////////////////

static FILE* file_open(char* buff, size_t off, const char* ext, const char* mode = NULL)
{
	FILE* ret = NULL;
	if (!mode)
		mode = "wb";
	strcpy(buff+off, ext);
	if (!(ret=fopen(buff, mode)))
		file_cleanup();
	return ret;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

static void write_short(FILE *f, unsigned short s)
{
//	unsigned short temp=htons(s);
//	fwrite(&temp, sizeof(temp), 1, f);
	fwrite(&s, 2, 1, f);
}

////////////////////////////////////////////////////////////////////////////////////////////////////

#define TABSIZE		4
#define CPPADD		8
#define JAVAADD		17
#define MAX_VNAME	32
#define STRMAX		(JAVAADD+MAX_VNAME)

static const char *tabit(const char *str, int fakelen, int len=-1)
{
	static char buf[STRMAX+1];
	
	if (!str)
		return NULL;

	if (len<0)
		len=lstrlen(str);

	if (fakelen+len<STRMAX)
	{
		strcpy(buf, str);
		char* c = buf+len;

		int tabs = (STRMAX/TABSIZE)-(fakelen+len)/TABSIZE;

		while (tabs--)
			*c++='\t';
		*c=0;
		return buf;
	}
	else
		return str;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

int _tmain(int argc, _TCHAR* argv[])
{
	(void)argc;
	(void)argv;

	CParser files;
	files.UseScriptFile(argc>1?argv[1]:"list.txt");

	char *jpackage = NULL;
	if (argc>2) jpackage = argv[2];

	int modulesCounter=0;

	while (files.SeekTokenVNAME())
	{
		int stringsCount=0;
		int fromStringCount=-1;
		char *fromString=NULL;
		int omitted=0;

		size_t name_size = lstrlen(files.GetTokenVNAME());
		char* file_name = new char[name_size+6];	// longest: ".java"
		memcpy(file_name, files.GetTokenVNAME(), name_size);
		strcpy(file_name+name_size, ".txt");

		CParser p;
		if (files.SeekTokenSTRING())
			p.UseScriptFile(files.GetTokenSTRING());
		else
			p.UseScriptFile(file_name);

		if (!(bin  = file_open(file_name, name_size, ".bin"))) break;
		if (!(idx  = file_open(file_name, name_size, ".off"))) break;
		if (!(h    = file_open(file_name, name_size, ".h", "wt"))) break;
		if (!(java = file_open(file_name, name_size, ".java", "wt"))) break;

		int nBinSize = 0;
		int nOffSize = 0;

		*(file_name+name_size)=0;

	//	fprintf(h, "// vim: set ts=%d:\n", TABSIZE);
	//	fprintf(java, "// vim: set ts=%d:\n", TABSIZE);

	//	fprintf(h, "// %s.h\n\n", file_name);
		fprintf(java, "/* Class generated from resources. */\n\n" );

		if(jpackage)
		{
			fprintf(java, "package %s;\n\n", jpackage);
		}
		fprintf(java, "public class %s \n{\n", file_name);

		fprintf(h, "#define ID_%s\t%d\n", tabit(file_name, 3+CPPADD), modulesCounter);
		fprintf(java, "\tpublic final static int %s\t= %d;\n", tabit("ID", JAVAADD), modulesCounter++);

		fprintf(h, "\n");
		fprintf(java, "\n");

		unsigned short int offset=0;
		write_short(idx, offset);

		while (!p.IsEOF())
		{
			while (p.SkipCHAR('$'))
			{
				p.RestoreOverwrittenChar();
				p.SkipZeroOrMoreTokenDelimitators();
				if (/*p.GetCrtChar() == '"' &&*/ p.SeekTokenSTRING(true))
				{
					fprintf(h, "%s", p.GetTokenSTRING());
					fprintf(java, "\t%s", p.GetTokenSTRING());
				}
				fprintf(h, "\n");
				fprintf(java, "\n");
			}

			while (p.SkipCHAR(',') || p.SkipCHAR(';') || p.SkipCHAR('='));

			if (fromString && p.SkipCHAR('*') && p.SeekTokenVNAME())
			{
				fprintf(h, "#define %s\t%d\n", tabit(p.GetTokenVNAME(), CPPADD), stringsCount-fromStringCount);
				fprintf(java, "\tpublic final static int %s\t= %d;\n", tabit(p.GetTokenVNAME(), JAVAADD), stringsCount-fromStringCount);
				continue;
			}

			if (p.SkipCHAR('+') && p.SeekTokenVNAME())
			{
				if (omitted>0)
				{
					fprintf(h, "// %d definitions missing\n", omitted);
					fprintf(java, "\t// %d definitions missing\n", omitted);
					omitted=0;
				}
				if (fromString)
				{
					fprintf(h, "#define %s\t(%s + %d)\n", tabit(p.GetTokenVNAME(), CPPADD), fromString, stringsCount-fromStringCount);
					fprintf(java, "\tpublic final static int %s\t= %s + %d;\n", tabit(p.GetTokenVNAME(), JAVAADD), fromString, stringsCount-fromStringCount);
					SAFE_DEL_ARRAY(fromString);
				}
				else
				{
					fprintf(h, "#define %s\t%d\n", tabit(p.GetTokenVNAME(), CPPADD), stringsCount);
					fprintf(java, "\tpublic final static int %s\t= %d;\n", tabit(p.GetTokenVNAME(), JAVAADD), stringsCount);
				}
				CopyDynString(&fromString, p.GetTokenVNAME());
				fromStringCount=stringsCount;

				p.RestoreOverwrittenChar();
				p.SkipZeroOrMoreTokenDelimitators();
				while (p.SkipCHAR('=')) { /*nothing*/ };
				if (p.SeekTokenSTRING(true))
				{
					++stringsCount;
					fwrite(p.GetTokenSTRING(), 1, 1+p.GetStringLength(), bin);
					offset+=1+p.GetStringLength();
					write_short(idx, offset);
				}
				continue;
			}

			if (fromString && p.SkipCHAR('-'))
			{
				SAFE_DEL_ARRAY(fromString);
				fromStringCount=-1;
				continue;
			}

			if (p.SeekTokenVNAME())
			{
				if (omitted>0)
				{
					fprintf(h, "// %d definitions missing\n", omitted);
					fprintf(java, "\t// %d definitions missing\n", omitted);
					omitted=0;
				}
				if (fromStringCount>=0)
				{
					fprintf(h, "#define %s\t(%s + %d)\n", tabit(p.GetToken(), CPPADD), fromString, stringsCount-fromStringCount);
					fprintf(java, "\tpublic final static int %s\t= %s + %d;\n", tabit(p.GetToken(), JAVAADD), fromString, stringsCount-fromStringCount);
					++stringsCount;
				}
				else
				{
					fprintf(h, "#define %s\t%d\n", tabit(p.GetToken(), CPPADD), stringsCount);
					fprintf(java, "\tpublic final static int %s\t= %d;\n", tabit(p.GetToken(), JAVAADD), stringsCount++);
				}
			}
			else
			{
				++omitted;
				++stringsCount;
			}

			p.RestoreOverwrittenChar();
			p.SkipZeroOrMoreTokenDelimitators();
			while (p.SkipCHAR('=')) { /*nothing*/ };
			if (p.SeekTokenSTRING(true))
			{
				fwrite(p.GetTokenSTRING(), 1, 1+p.GetStringLength(), bin);
				offset += 1+p.GetStringLength();
				write_short(idx, offset);
			}
			else
			{
				// Error
				fprintf(h,    "\n// ERROR !!!\n");
				fprintf(java, "\n// ERROR !!!\n");
				break;
			}
		}

		--omitted;
		if (omitted>0)
		{
			fprintf(h,    "// %d definitions missing\n", omitted);
			fprintf(java, "\t// %d definitions missing\n", omitted);
		}

		nBinSize = offset;
		nOffSize = 2 + stringsCount * 2;

		fseek(idx, 0, SEEK_SET);
		write_short(idx, stringsCount);

		fprintf(h, "\n");
		fprintf(java, "\n");

		fprintf(h, "#define NUM_STRINGS_%s\t%d\n", tabit(file_name, 12+CPPADD), stringsCount);
		fprintf(java, "\tpublic final static int %s\t= %d;\n", tabit("NUM_STRINGS", JAVAADD), stringsCount);

		fprintf(h, "#define BIN_SIZE_%s\t%d\n", tabit(file_name, 12+CPPADD), nBinSize);
		fprintf(java, "\tpublic final static int %s\t= %d;\n", tabit("BIN_SIZE", JAVAADD), nBinSize);

		fprintf(h, "#define OFF_SIZE_%s\t%d // 2 + %d * 2\n", tabit(file_name, 12+CPPADD), nOffSize, stringsCount);
		fprintf(java, "\tpublic final static int %s\t= %d; // 2 + %d * 2\n", tabit("OFF_SIZE", JAVAADD), nOffSize, stringsCount);

		fprintf(java, "}\n\n");

		file_cleanup();
		delete[] file_name;
		SAFE_DEL_ARRAY(fromString);
	}

	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////

