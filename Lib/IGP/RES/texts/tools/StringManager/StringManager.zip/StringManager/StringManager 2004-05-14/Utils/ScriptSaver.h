// ScriptSaver.cpp
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Author(s): Ionut Matasaru
//
//	History: 16.09.2003, created
//			 16.09.2003, updated
//
////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

////////////////////////////////////////////////////////////////////////////////////////////////////

#define MAX_BUFFER_SIZE			2048
#define DEFAULT_TAB_SPACES		4
#define MIN_INDENT				0
#define MAX_INDENT				100

////////////////////////////////////////////////////////////////////////////////////////////////////

class CScriptSaver
{
// Methods...
public:
	CScriptSaver();
	~CScriptSaver();

//	HRESULT OpenFile(char* szFile);
	void SetFile(CFile* pFile)			{ m_pFile = pFile; }
	void IncIndent()					{ if (m_nIndent<MAX_INDENT) m_nIndent++; }
	void DecIndent()					{ if (m_nIndent>MIN_INDENT) m_nIndent--; }
	void SetTabSpaces(int nTabSpaces)	{ m_nTabSpaces = nTabSpaces; }

	void WriteText(const char* szText);
	void WriteTextF(const char* szFormat, ...);
	void WriteIndent();
	void WriteIndentText(const char* szText);
	void WriteIndentTextF(const char* szFormat, ...);

// Attributes...
public:
	CFile*	m_pFile;
//	BOOL	m_bOwnFile;
	int		m_nIndent;
	int		m_nTabSpaces;
};

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
