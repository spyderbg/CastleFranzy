Input: un fisier `list.txt' cu numele fisierelor (fara extensia .txt) intre ghilimele.

Output:
un fisier .h si unul .java cu definitii;
un fisier .bin cu stringurile ca array de bytes, fiecare string terminat cu un 0;
un fisier .idx cu urmatorul format:
short	n	numarul de stringuri
n	offsets	offsetul urmatorului string in .bin (primul string are offset 0).
