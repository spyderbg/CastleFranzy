@echo off
setlocal enabledelayedexpansion

call init.bat

set PRJ=JStringExporterXLS

cd classes
"%JDK%\bin\jar.exe" cfm JStringExporterXLS.jar ..\MANIFEST.MF *.*
cd ..

set OBFUSCATE=false
set USE_PROGUARD=false

if "%OBFUSCATE%"=="false" goto _end

:_obfuscate
if exist obfuscated rmdir /S /Q obfuscated > NUL
mkdir obfuscated
cd obfuscated

if "%USE_PROGUARD%"=="false" goto _jshrink

:_proguard
if exist JStringExporterXLS.jar del JStringExporterXLS.jar > NUL
echo -libraryjars "%JDK%\jre\lib\rt.jar";..\log4j-1.2.14.jar       > %PRJ%.pro
echo -injars ..\classes\JStringExporterXLS.jar                     >> %PRJ%.pro
echo -outjar JStringExporterXLS.jar                     		   >> %PRJ%.pro
echo -dontobfuscate  >> %PRJ%.pro
echo -overloadaggressively                                         >> %PRJ%.pro
echo -defaultpackage ''                                            >> %PRJ%.pro
echo -dontusemixedcaseclassnames                                   >> %PRJ%.pro
echo -allowaccessmodification                                      >> %PRJ%.pro
echo -keep public class JStringExporterXLS {    public static void main(java.lang.String[]);} >> %PRJ%.pro
echo -dontnote                                                     >> %PRJ%.pro
echo -dontwarn                                                     >> %PRJ%.pro
%JAVA_EXE% -jar ..\proguard.jar @%PRJ%.pro
goto _endobfuscate

:_jshrink
if exist JStringExporterXLS.jar del JStringExporterXLS.jar > NUL
set JSPRAM=-l -classpath %JDK%\jre\lib\rt.jar;log4j-1.2.14.jar ..\classes\JStringExporterXLS.jar -keep JStringExporterXLS -o JStringExporterXLS.jar
"%JDK%\bin\java.exe" -jar ..\jshrink.jar %JSPRAM% > ..\js.log

:_endobfuscate
cd ..

:_end
pause