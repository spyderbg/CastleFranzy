import java.util.Vector;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.IOException;
//import java.util.Locale;

//import java.io.File;
//import java.util.Date;
//import jxl.*;

import java.util.Iterator;
import java.io.InputStream;
import java.io.FileInputStream;
import org.apache.poi.hssf.*;
import org.apache.poi.poifs.filesystem.*;
import org.apache.poi.hssf.usermodel.*;

public class JStringExporterXLS_Main
{
    ////////////////////////////////////////////////////////////////////////////////////////////////////

    final static int RET_OK   = 0;
    final static int RET_ERR  = -1;

    final static String COMMAND_SYNTAX = "\n" +
    "Usage: XLSStringManager -xls Input_XLS_File\n" +
    "       -row_start first_row\n" +
    "       -col_id col_id_no\n" +
    "       -col_strings col_strings_no\n" +
    "       [options]\n" +
    "\n" +
    "where [options]:\n" +
    "   -strings OutputFileName		Output file in .strings format\n" +
    "   -nobreak\n" +
    "   -row_end last_row\n" +
    "   -sheet sheetIndex           Index of the sheet from which the data is read\n";

    ////////////////////////////////////////////////////////////////////////////////////////////////////

    static String szErrDescription;

    ////////////////////////////////////////////////////////////////////////////////////////////////////

//    static FileOutputStream	fos = null;
    static OutputStreamWriter writer = null;


    static boolean bSaveAsUnicode;

    ////////////////////////////////////////////////////////////////////////////////////////////////////

	public static void execute(String args[])
	{
		System.out.println("XLSStringManager v0.1 (c) Gameloft 2006 by Dragos Velicu");

        String szInputXLSFile = null;
        String szOutputStringFile = null;
        boolean bNoBreak = false;
        int nColId = -1;
        int nColStrings = -1;
        int nRowStart = -1;
        int nRowEnd = -1;
        int nSheet = 0;
        bSaveAsUnicode = false;

        for (int i = 0; i < args.length; i++)
        {
            if (args[i].compareTo("-nobreak") == 0)
                bNoBreak = true;
            else if (args[i].compareTo("-unicode") == 0)
            {
                bSaveAsUnicode = true;
			}
            else if (args[i].compareTo("-xls") == 0)
            {
                szInputXLSFile = args[i + 1];
                i++;
            }
            else if (args[i].compareTo("-sheet") == 0)
            {
                nSheet = strToNumber(args[i + 1]);
                if (nSheet == -9999)
                {
                    System.out.println("Parse number exception: " + args[i + 1] + "\n");
                    return;
                }
                i++;
            }
            else if (args[i].compareTo("-row_start") == 0)
            {
                nRowStart = strToNumber(args[i + 1]);
                if (nRowStart == -9999)
                {
                    System.out.println("Parse number exception: " + args[i + 1] + "\n");
                    return;
                }
                i++;
            }
            else if (args[i].compareTo("-row_end") == 0)
            {
                nRowEnd = strToNumber(args[i + 1]);
                if (nRowEnd == -9999)
                {
                    System.out.println("Parse number exception: " + args[i + 1] + "\n");
                    return;
                }
                i++;
            }
            else if (args[i].compareTo("-col_id") == 0)
            {
                nColId = strToNumber(args[i + 1]);
                if (nColId == -9999)
                {
                    System.out.println("Parse number exception: " + args[i + 1] + "\n");
                    return;
                }
                i++;
            }
            else if (args[i].compareTo("-col_strings") == 0)
            {
                nColStrings = strToNumber(args[i + 1]);
                if (nColStrings == -9999)
                {
                    System.out.println("Parse number exception: " + args[i + 1] + "\n");
                    return;
                }
                i++;
            }
            else if (args[i].compareTo("-strings") == 0)
            {
                szOutputStringFile = args[i + 1];
                i++;
            }
            else
            {
                System.out.println("Invalid argument: " + args[i] + "\n");
                System.out.println(COMMAND_SYNTAX);

                return;
            }

            if (i >= args.length)
            {
                System.out.println("Missing parameter for the argument: " + args[i] + "\n");
                System.out.println(COMMAND_SYNTAX);

                return;
            }
        }

        if (szInputXLSFile == null)
        {
            System.out.println("Missing mandatory argument '-xls'\n");
            System.out.println(COMMAND_SYNTAX);

            return;
        }
        if (nRowStart == -1)
        {
            System.out.println("Missing mandatory argument '-row_start'\n");
            System.out.println(COMMAND_SYNTAX);

            return;
        }
        if ((nRowEnd != -1) && (nRowEnd < nRowStart))
        {
            System.out.println("Argument 'row_end' must be bigger then the argument 'row_start'\n");
            System.out.println(COMMAND_SYNTAX);

            return;
        }
        if (nColId == -1)
        {
            System.out.println("Missing mandatory argument '-col_id'\n");
            System.out.println(COMMAND_SYNTAX);

            return;
        }
        if (nColStrings == -1)
        {
            System.out.println("Missing mandatory argument '-col_strings'\n");
            System.out.println(COMMAND_SYNTAX);

            return;
        }

		int res = RET_OK;
		try
		{
			res = parseXMLFile(szInputXLSFile, nSheet, nRowStart, nRowEnd, nColId, nColStrings, szOutputStringFile, bNoBreak);
		}
		catch(Exception e)
		{
            System.out.println("ERROR: " + e.getMessage() + "\n");
            e.printStackTrace();
            return;
		}
        if (RET_ERR == res)
        {
            System.out.println("ERROR: " + szErrDescription + "\n");
            return;
        }
	}

    ////////////////////////////////////////////////////////////////////////////////////////////////////

    static int strToNumber(String str)
    {
        int n = 0;

        try
        {
            n = Integer.valueOf(str).intValue();
        }
        catch (Exception e)
        {
            return -9999;
        }

        return n;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////

    static String NoBreak(String str)
    {
        String[] strToReplace = {" !", " ?"};

        int size = strToReplace.length;
        for(int i = 0; i < size; i++)
        {
	        int pos = -1;
	        do
	        {
		        pos = str.indexOf(strToReplace[i]);
                if (pos != -1)
                {
                    char[] _tmp = str.toCharArray();
                    _tmp[pos] = 0xA0;
                    str = new String(_tmp);
                }
	        }
	        while(pos != -1);
        }

        return str;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////

	public static String Replace(String str, String str1, String str2)
	{
		int offset = 0;

		do
		{
			offset = str.indexOf(str1, offset);

			if (offset != -1)
			{
				str = str.substring(0, offset) + str2 + str.substring(offset + str1.length(), str.length());

				offset += str1.length();
			}
		}
		while(offset != -1);

		return str;
	}

	public static String TrimEnd(String str)
	{
		int offset = str.length() - 1;
		for(; offset >= 0; offset--)
		{
			if (str.charAt(offset) != ' ' &&
				str.charAt(offset) != '\t')
				break;
		}

		if (offset < 0)
			str = "";
		else if (offset != str.length() - 1)
		{
			str = str.substring(0, offset);
		}

		return str;
	}

    ////////////////////////////////////////////////////////////////////////////////////////////////////

    static int TABSIZE	    = 4;
    static int CPPADD		= 8;
    static int JAVAADD	    = 17;
    static int STRINGSADD	= 20;
    static int MAX_VNAME	= 32;
    static int STRMAX		= (STRINGSADD+MAX_VNAME);

    public static String tabit(String str, int fakelen, int len)
    {
        String buf = "";

        if (str == null)
	        return null;

        if (len<0)
	        len=str.length();

        if (fakelen+len<STRMAX)
        {
            buf = str;
            int c = len;

	        int tabs = (STRMAX/TABSIZE)-(fakelen+len)/TABSIZE;

            while (tabs != 0)
            {
                buf += "\t";
                c++;
                tabs--;
            }

	        return buf;
        }
        else
	        return str;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////

	public static int parseXMLFile(String szInputXLSFile, int nSheet, int nRowStart, int nRowEnd, int nColId, int nColStrings, String szOutputStringFile, boolean bNoBreak)
	{
        String szTmp;
        if (szOutputStringFile == null)
            szOutputStringFile = "" + szInputXLSFile.substring(0, szInputXLSFile.indexOf('.'));

        Vector arrayColId = new Vector();
        Vector arrayColStrings = new Vector();

		try
		{
			InputStream is = new FileInputStream(szInputXLSFile);
			POIFSFileSystem pos = new POIFSFileSystem(is);
			HSSFWorkbook workbook = new HSSFWorkbook(pos);
			if (nSheet < 0 || nSheet >= workbook.getNumberOfSheets() )
			{
				szErrDescription = "Invalid sheet index: " + nSheet;

				return RET_ERR;
			}

			HSSFSheet sheet = workbook.getSheetAt(nSheet);
			Iterator rows = sheet.rowIterator();
			int rowId = 0;
			while (rows.hasNext())
			{
				HSSFRow row = (HSSFRow) rows.next();

            	HSSFCell cellId = row.getCell((short)(nColId - 1));
            	HSSFCell cellString = row.getCell((short)(nColStrings - 1));

				String colId = (cellId== null)||(cellId.getRichStringCellValue()==null)?"":cellId.getRichStringCellValue().getString();
				String colString = "";
				if(cellString != null)
				{
					switch(cellString.getCellType())
					{
						case HSSFCell.CELL_TYPE_NUMERIC:
							colString = Double.toString(cellString.getNumericCellValue());
						break;
						
						case HSSFCell.CELL_TYPE_BLANK:
							colString = " ";
						break;
						
						default:
							colString = (cellString.getRichStringCellValue()==null) ? "" : cellString.getRichStringCellValue().getString();
						break;
					}
				}

				arrayColId.add(colId);
				arrayColStrings.add(colString);
				rowId++;
            }

		}
		catch(Exception e)
		{
            szErrDescription = e.getMessage();

            return RET_ERR;
		}

        String file_name = szOutputStringFile;
        if (file_name.indexOf(".") == -1)
        	file_name += ".strings";

		try
		{
			//fos = new FileOutputStream(file_name);
			if(bSaveAsUnicode)
				writer = new OutputStreamWriter( new FileOutputStream(file_name), "Unicode" );
			else
				writer = new OutputStreamWriter( new FileOutputStream(file_name));

		}
		catch(Exception e)
        {
            szErrDescription = "Could not open for write the file '" + szOutputStringFile + ".strings'";

	        return RET_ERR;
        }

        int xml_offset = nRowStart - 1;

        int sizeToParse = arrayColId.size();
        if (nRowEnd != -1)
	        sizeToParse = nRowEnd;

        while(xml_offset < sizeToParse)
        {
            String strText = arrayColStrings.get(xml_offset).toString();
            String strId = arrayColId.get(xml_offset).toString();

	        strId.trim();

	        String strTab = "\t";

            if (strId.length() > 0)
	        {
                if (strId.compareTo("$") == 0 ||
                    strId.charAt(0) == '+' ||
                    strId.charAt(0) == '*' ||
                    strId.charAt(0) == '#')
			        strTab = "";
	        }

            while (xml_offset + 1 < arrayColId.size() && arrayColId.get(xml_offset + 1).toString() == "@")
	        {
                strText += "\n" + arrayColStrings.get(xml_offset + 1);

		        if (strId == "")
			        strTab = "";
		        xml_offset++;
	        }
	        if (bNoBreak)
		        strText = NoBreak(strText);

			strText = Replace(strText, "\u2026", "...");//8230 - "\u2026"
			strText = Replace(strText, "\u2019", "'");//8217 - "\u2019"
			strText = Replace(strText, "\u2013", "-");//8211 - "\u2013"
			strText = Replace(strText, "\u00A0", " ");//160 - "\u00A0"
			strText = Replace(strText, "\u201C", "\"");//8220 - "\u2019"
			strText = Replace(strText, "\u201D", "\"");//8221 - "\u2019"
			strText = Replace(strText, "\u00AB", "\"");//171 - "\u00AB"
			strText = Replace(strText, "\u00BB", "\"");//187 - "\u00BB"

			//replace Cyrillic with the Latin correspondent
			strText = Replace(strText, "\u0410", "A");//1040 - "\u0410"
			strText = Replace(strText, "\u0412", "B");//1042 - "\u0412"
			strText = Replace(strText, "\u0415", "E");//1045 - "\u0415"
			strText = Replace(strText, "\u041C", "M");//1052 - "\u041C"
			strText = Replace(strText, "\u041D", "H");//1053 - "\u041D"
			strText = Replace(strText, "\u041E", "O");//1054 - "\u041E"
			strText = Replace(strText, "\u0420", "P");//1056 - "\u0420"
			strText = Replace(strText, "\u0421", "C");//1057 - "\u0421"
			strText = Replace(strText, "\u0422", "T");//1058 - "\u0422"
			strText = Replace(strText, "\u0425", "X");//1061 - "\u0425"

	        String strLine;
            strLine = strTab;
            strLine += (strText.compareTo("") == 0 || strId.compareTo("") == 0) ? strId : tabit(strId, STRINGSADD, -1);
            strLine += (strText.compareTo("") == 0) ? "" : "\"" + (strText.trim().compareTo("\"\"") == 0 ? "" : strText) + "\"";
	        TrimEnd(strLine);

			try
			{
	            for (int i = 0; i < strLine.length(); i++)
	            {
	                char ch = strLine.charAt(i);
	                writer.write(ch);
	            }
	            writer.write('\n');
			}
			catch(Exception e)
			{
	            szErrDescription = "Could not write to the file '" + szOutputStringFile + "' : [" + e.getMessage() + "]";
		        return RET_ERR;
			}

	        xml_offset++;
        }
		 try
		 {
			if ( writer != null )
			 {
				writer.close();
			 }
		 }
		 catch ( IOException e )
		 {}
		return RET_OK;
	}

    ////////////////////////////////////////////////////////////////////////////////////////////////////
}