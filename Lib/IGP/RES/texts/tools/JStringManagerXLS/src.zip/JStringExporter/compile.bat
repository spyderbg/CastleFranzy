call init.bat

rmdir /r classes

mkdir classes

%JAVAC% -d classes *.java org\apache\poi\ddf\*.java org\apache\poi\dev\*.java org\apache\poi\hpsf\*.java org\apache\poi\util\*.java org\apache\poi\hpsf\wellknown\*.java org\apache\poi\hssf\dev\*.java org\apache\poi\hssf\eventmodel\*.java org\apache\poi\hssf\eventusermodel\*.java org\apache\poi\hssf\model\*.java org\apache\poi\hssf\record\*.java org\apache\poi\hssf\usermodel\*.java org\apache\poi\hssf\util\*.java org\apache\poi\hssf\record\aggregates\*.java org\apache\poi\hssf\record\formula\*.java org\apache\poi\poifs\common\*.java org\apache\poi\poifs\dev\*.java org\apache\poi\poifs\eventfilesystem\*.java org\apache\poi\poifs\filesystem\*.java org\apache\poi\poifs\property\*.java org\apache\poi\poifs\storage\*.java 