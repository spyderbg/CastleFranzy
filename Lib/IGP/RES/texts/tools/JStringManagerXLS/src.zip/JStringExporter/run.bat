call init.bat

rem %JAVA_EXE% -classpath .;classes JStringExporterXLS -xls LostTexts_initial.xls  -row_start 4 -col_id 2 -col_strings 8 -strings SP -nobreak
%JAVA_EXE% -Duser.language=en -Duser.country=US -Duser.variant=US -jar obfuscated\JStringExporterXLS.jar -xls LostTexts_initial.xls  -row_start 4 -col_id 2 -col_strings 8 -strings SP -nobreak
