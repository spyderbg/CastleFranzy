public class JStringExporterXLS
{
	public static void main(String args[])
	{
		JStringExporterXLS_Main.execute(args);
	}
}