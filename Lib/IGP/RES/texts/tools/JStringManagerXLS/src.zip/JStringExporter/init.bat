set JDK=c:\j2sdk1.4.2_16
set JAVAC=%JDK%\bin\javac.exe
set JAVA_EXE=%JDK%\bin\java.exe
