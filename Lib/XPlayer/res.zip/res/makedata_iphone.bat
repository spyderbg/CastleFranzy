TITLE realfootball2010_richphone_JP resource packing

SET texconv="..\Tools\texconv.exe"
SET respack="..\Tools\ResPack.exe"
SET aurora="..\Tools\aurora\AuroraGT.exe"
SET DATA_DIR=.\_Data

md %DATA_DIR%

pushd %DATA_DIR%
DEL /q *.* 
for /D %%i in (*.*) do (
	cd %%i
	del /q *.*
	cd ..
)
popd

%texconv% -d others -bmp
%texconv% -d texture -bmp

%texconv% sprite\font_12.tga -16
%texconv% sprite\font_15.tga -16
%texconv% sprite\font_20.tga -16
%texconv% sprite\font_25.tga -16
%texconv% sprite\padbutton.tga -32
%texconv% sprite\menu_bar.tga -32

%aurora% sprite\config.sprcmd

copy sprite\*.gtx %DATA_DIR%\
copy sprite\*.bsprite %DATA_DIR%\
copy sprite\*.bin %DATA_DIR%\
del sprite\*.gtx  /q
del sprite\*.bsprite  /q

copy others\*.gtx %DATA_DIR%\
del others\*.gtx  /q

%respack% -s %DATA_DIR% -d res.pak -zlib

md ..\Win32\iPhoneOnlineDemo\Demo\data
copy res.pak ..\Win32\iPhoneOnlineDemo\Demo\data\res.pak
copy others\oconf.bar ..\Win32\iPhoneOnlineDemo\Demo\data\

copy res.pak ..\mac\data\res.pak
copy others\oconf.bar ..\Win32\iPhoneOnlineDemo\Demo\data\

PAUSE
